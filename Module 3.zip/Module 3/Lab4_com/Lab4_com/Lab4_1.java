package Lab4_com;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class Lab4_1 {
	
		 static File file = new File("C:\\Users\\Trainee User\\Desktop\\Srinivas.txt");
		 static String reverse;
		 @SuppressWarnings("deprecation")
		public static void main(String[] args) throws IOException
	     {
			    

			    FileInputStream f = null;
			    BufferedInputStream b = null;
			    DataInputStream d = null;
			 
			    try
			    {
			      f = new FileInputStream(file);
			      b = new BufferedInputStream(f);
			      d = new DataInputStream(b);
			      
			      while (d.available() != 0)
			      {
			    	 reverse = new StringBuffer(d.readLine()).reverse().toString();

			      }
			 
			 
			     
			      f.close();
			      b.close();
			      d.close();
			 
			    } catch (FileNotFoundException e) 
			    {
			      e.printStackTrace();
			    } catch (IOException e)
			    {
			      e.printStackTrace();
			    }
			    
			    BufferedWriter bw = null;
				FileWriter fw = null;

				try
				{

					String content = reverse;

					fw = new FileWriter(file);
					bw = new BufferedWriter(fw);
					bw.write(content);

					System.out.println("Reverse Done");

				} catch (IOException e)
				{

					e.printStackTrace();

				} finally 
				
				{
					try
					{

						if (bw != null)
							bw.close();

						if (fw != null)
							fw.close();

					} catch (IOException ex)
					{

						ex.printStackTrace();
						}

				}
	     }
}



			   
			    
			    
			    

	     


	


	