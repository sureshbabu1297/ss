package Lab2_com;



	public class Userdefined extends Exception{
		public Userdefined() {
			super();
		}
		public Userdefined(String s){
			super(s);
		}
	}


