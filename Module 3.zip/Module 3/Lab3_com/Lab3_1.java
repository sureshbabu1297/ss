package Lab2_com;

public class Lab3_1 {
	
	
	

	//public class Person3_1 {
		String firstName;
		String lastName;
		char gender;
		
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) throws Userdefined{
			if(firstName == " ") {
				throw new Userdefined("firstname cannot be blank!!");
			}
			else {
			this.firstName = firstName;
			}
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) throws Userdefined{
			if(lastName == " ") {
				throw new Userdefined("Lastname cannot be blank!!");
			}
			else {
			this.lastName = lastName;
			}
		}
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		}
		
		Lab3_1(){
			System.out.println("Default Constructor");
		}
		Lab3_1(String firstName,String lastName,char gender){
			this.firstName=firstName;
			this.lastName=lastName;
			this.gender=gender;
			
		}
		public void print() {
			System.out.println(this);
		}
		public String toString() {
			return getFirstName()+" "+getLastName()+" "+getGender();
		}

	}

	
