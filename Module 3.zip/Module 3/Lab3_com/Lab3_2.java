package Lab2_com;

public class Lab3_2 {
String name;
float age;
Lab3_2(){
	System.out.println("Person age default constructor");
}
Lab3_2(String name,float age){
	super();
	this.name=name;
	this.age=age;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getAge() {
	return age;
}
public void setAge(float age) throws Userdefined3_2 {
	if(age<=15) {
		throw new Userdefined3_2("Age should be greater than 15");
	}
	else
	{
	this.age = age;
	}
}
public void print() {
	System.out.println(this);
}
public String toString() {
	return getName()+" "+getAge();
}


}
