package Lab2_com;


	
	import java.util.Scanner;

	public class Lab3_1main {

		public static void main(String[] args) {
			try {
				Scanner sc=new Scanner(System.in);
				Lab3_1 p=new Lab3_1();
				System.out.println("Enter the First Name");
				String firstName=sc.nextLine();
				p.setFirstName(firstName);
				System.out.println("Enter the Last Name");
				String lastName=sc.nextLine();
				p.setLastName(lastName);
				System.out.println("Enter the gender");
				char gender=sc.next().charAt(0);
				p.setGender(gender);
				p.print();
			}
			catch(Userdefined e)
			{
				System.out.println("Fname and Lname cannot be blank!!");
			}
		}

	}

