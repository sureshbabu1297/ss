package Lab2_com;

import java.util.Scanner;

public class Lab3_2main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Lab3_2 p=new Lab3_2();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the name");
			String name=sc.nextLine();
			p.setName(name);
			System.out.println("Enter the age");
			float age=sc.nextFloat();
			p.setAge(age);
			p.print();
		}
		catch(Exception m) {
			System.out.println("Exception Occured "+m);
		}
	}

}
