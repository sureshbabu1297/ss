package com.Lab5;

import org.junit.*;
import org.junit.Test;
import static org.junit.Assert.*;


public class Lab5_1junit {
	@Test
	public void testGetFullName()
	{
	System.out.println("from TestPerson2");
	Lab5_1 per = new Lab5_1("Robert","King");
	Assert.assertEquals("Robert King",per.getFullName());
	}
	@Test (expected=IllegalArgumentException.class)
	public void testNullsInName()
	{
		System.out.println("from TestPerson2 testing exceptions");
		Lab5_1 per1 = new Lab5_1(null,null);
	}
	
}
