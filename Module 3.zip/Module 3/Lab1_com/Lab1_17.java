package Lab_work;

public class Lab1_17 {
	
	
	public class Person1 {
		public String firstName;
		public String lastName;
		public char gender;
		public String phonenumber;
		
		public String getPhonenumber() {
			return phonenumber;
		}

		public void setPhonenumber(String phonenumber) {
			this.phonenumber = phonenumber;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public char getGender() {
			return gender;
		}

		public void setGender(char gender) {
			this.gender = gender;
		}
		
		public Person1(){
			System.out.println("Default Constructor");
		}
		public Person1(String firstName,String lastName,char gender,String phonenumber) {
			//System.out.println("First Name: "+firstName+" Last Name: "+lastName+" Gender: "+gender);
			this.firstName=firstName;
			this.lastName=lastName;
			this.gender=gender;
			this.phonenumber=phonenumber;
		}
		
	}
}
	
	

	
