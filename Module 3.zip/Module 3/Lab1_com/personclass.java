package Lab_work;

public class personclass {

		
			public String firstName;
			public String lastName;
			public char gender;
			
			public String getFirstName() {
				return firstName;
			}

			public void setFirstName(String firstName) {
				this.firstName = firstName;
			}

			public String getLastName() {
				return lastName;
			}

			public void setLastName(String lastName) {
				this.lastName = lastName;
			}

			public char getGender() {
				return gender;
			}

			public void setGender(char gender) {
				this.gender = gender;
			}
			
			public personclass(){
				System.out.println("Default Constructor");
			}
			public personclass(String firstName,String lastName,char gender) {
				System.out.println("First Name: "+firstName+" Last Name: "+lastName+" Gender: "+gender);
			}
			public static void main(String[] args) {
				// TODO Auto-generated method stub
				personclass p=new personclass();
				personclass c=new personclass("Suresh","Raina",'M');
			}


	}

