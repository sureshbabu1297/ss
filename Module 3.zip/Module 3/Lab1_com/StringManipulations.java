package lab1;

import java.util.Scanner;

class StringOptions{
	public void displayOptions(){
		System.out.println("Enter your choice");
		System.out.println("1.Add string to itself\n2.Replace odd positions with #\n3.Remove duplicate characters in the String\n4.Change odd characters to upper case" );
	}
	public String doManipulation(int choice,String word){
		if(choice==1){
			return word+word;
		}
		else if(choice==2){
			char letters[]=word.toCharArray();
			for(int i=0;i<letters.length;i++){
				if((i+1)%2!=0){
					letters[i]='#';
				}
			}
			String s=new String(letters);
			return s;
		}
		else if(choice==3){
			String dup="";
			for(int i=0;i<word.length();i++){
				if(!(dup.contains(String.valueOf(word.charAt(i))))){
					dup+=word.charAt(i);
				}
			}
			return dup;
		}
		else
		{
			char letters[]=word.toCharArray();
			for(int i=0;i<letters.length;i++){
				if(((i+1)%2!=0)&&(letters[i]>=97&&letters[i]<=122)){
					letters[i]=(char) (letters[i]-32);
				}
			}
			String s=String.valueOf(letters);
			return s;
		}
	}
}
public class StringManipulations {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		StringOptions obj = new StringOptions();
		obj.displayOptions();
		int choice=in.nextInt();
		String help=in.nextLine();
		String word=in.nextLine();
		System.out.println(obj.doManipulation(choice,word));
	}
}
