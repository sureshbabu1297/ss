package lab1;

import java.util.Scanner;

public class DisplayDetails {

	public static void main(String[] args) {
		String firstName,lastName,gender;
		int age;
		double weight;
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the First Name");
		firstName=in.nextLine();
		System.out.println("Enter the Last Name");
		lastName=in.nextLine();
		System.out.println("Enter the Gender");
		gender=in.nextLine();
		System.out.println("Enter the Age");
		age=in.nextInt();
		System.out.println("Enter the Weight");
		weight=in.nextDouble();
		System.out.println("Person Details:");
		System.out.println("First Name: "+firstName+"\nLast Name: "+lastName+"\nGender: "+gender+"\nAge: "+age+"\nWeigth: "+weight);;

	}

}
