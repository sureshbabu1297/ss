package lab1;

class CommandLineArgument {
	public static void main(String[] args) {
		int number=Integer.parseInt(args[0]);
		if(number>=0)
		{
			System.out.println("You Entered positive number");
		}
		else
		{
			System.out.println("You Entered negative number");
		}
	}
}
